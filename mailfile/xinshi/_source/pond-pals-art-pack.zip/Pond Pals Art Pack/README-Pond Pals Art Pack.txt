Pond Pals Art Pack
11/13/2024

Sprites and tiles from the with the love studios game Pond Pals.
https://withthelove.itch.io/pond-pals

Presented as my way of giving back to the OGA community and saying thanks to all the artists who have contributed works contributed works, time and love to the OpenGameArt.org project.


The game is free, so if you like the art, give it a try!

By
Scott Matott sXe
and
Sammy Matott



Attribution instructions:
Credit 'Scott Matott and Sammy Matott' and include a link back to pack's home on OpenGameArt.org
https://opengameart.org/content/pond-pals-art-pack

Released under terms of OGA-BY-3.0, take your pick.
See included OGA-BY-3.0.txt file for full license details. 
(tldr; use as you please but give credit)

Change Log:
11/13/2024 - First release
